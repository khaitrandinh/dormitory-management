import React from 'react';

const AdminPage = () => {
    return (
        <div className="container mt-5">
            <h1>Trang quản trị Admin</h1>
            <p>Chỉ Admin có quyền xem trang này.</p>
        </div>
    );
};

export default AdminPage;
