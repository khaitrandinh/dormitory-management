import React from 'react';

const StudentPage = () => {
    return (
        <div className="container mt-5">
            <h1>Trang sinh viên (Student)</h1>
            <p>Chỉ sinh viên có quyền xem trang này.</p>
        </div>
    );
};

export default StudentPage;
