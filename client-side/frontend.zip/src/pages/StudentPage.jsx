const StudentManage = () => {
    return (
        <div>
            <h2>Quản lý sinh viên</h2>
            <p>Thông tin về sinh viên, phòng, tình trạng thanh toán...</p>
        </div>
    );
};

export default StudentManage;
